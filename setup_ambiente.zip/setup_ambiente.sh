#!/bin/bash
echo "start config"
set -euo pipefail

if ! sudo swapon --show | grep -q '/swapfile'; then
	sudo fallocate -l 2G /swapfile
	sudo chmod 600 /swapfile
	sudo mkswap /swapfile
	sudo swapon /swapfile
	echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
fi

get_public_ip() {
  local token ip
  token=$(curl -s -m 2 -X PUT "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 60" || true)
  if [ -n "$token" ]; then
    ip=$(curl -s -m 2 -H "X-aws-ec2-metadata-token: $token" \
      "http://169.254.169.254/latest/meta-data/public-ipv4" || true)
  fi
  # Fora da AWS (ou se o metadata falhar), consulta um serviço externo
  if [ -z "${ip:-}" ]; then
    ip=$(curl -s -m 5 "https://checkip.amazonaws.com" || true)
  fi
  echo "${ip//[[:space:]]/}"
}

# Usa SERVER_HOST se foi passado; senão detecta automaticamente
SERVER_HOST="${SERVER_HOST:-$(get_public_ip)}"

if [ -z "$SERVER_HOST" ]; then
  echo "Não consegui descobrir o IP público. Rode: SERVER_HOST=seu.ip ./setup_ambiente.sh"
  exit 1
fi
echo "IP público usado: $SERVER_HOST"

sudo apt update && sudo apt upgrade -y

echo "Set variaveis de ambiente: "
APP_NAME="OButeco"
DB_USER="henriquem"
DB_NAME="db_obuteco"
DB_PASSWORD="$(openssl rand -hex 16)"
JWT_SECRET="$(openssl rand -base64 48)"
APP_ADMIN_SENHA="$(openssl rand -hex 16)"
PROJECT_DIR="$HOME/OButeco"
BACK_PORT=8080
CORS_ALLOWED_ORIGINS=http://$SERVER_HOST,http://localhost:4200

mkdir -p "$PROJECT_DIR"

echo "User: $DB_USER"
echo "Banco: $DB_NAME"

echo -e "
DB_USER=$DB_USER
DB_NAME=$DB_NAME
DB_PASSWORD=$DB_PASSWORD
JWT_SECRET=$JWT_SECRET
APP_ADMIN_SENHA=$APP_ADMIN_SENHA
CORS_ALLOWED_ORIGINS=$CORS_ALLOWED_ORIGINS" > "$PROJECT_DIR/credenciais.txt"

echo "Instalando pacotes: "

sudo apt install -y postgresql postgresql-contrib openjdk-17-jdk apache2 openssl maven git nodejs npm

echo "========="

echo "Java Version: "
java --version

echo "=========="
echo "Config postgres"

if [ -z "$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'")" ]; then
  sudo -u postgres psql -v db_user="$DB_USER" <<'SQL'
CREATE ROLE :"db_user" LOGIN;
SQL
fi

sudo -u postgres psql -v db_user="$DB_USER" -v db_password="$DB_PASSWORD" <<'SQL'
ALTER ROLE :"db_user" WITH LOGIN PASSWORD :'db_password';
SQL

if [ -z "$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'")" ]; then
  sudo -u postgres createdb -O "$DB_USER" "$DB_NAME"
fi

sudo -u postgres psql -d "$DB_NAME" -c "GRANT ALL ON SCHEMA public TO \"$DB_USER\";"

echo "Usuário: $DB_USER | Banco: $DB_NAME"

echo "Start Servicos"
echo "========="

sudo systemctl enable --now apache2 postgresql
sudo a2enmod rewrite proxy proxy_http
sudo systemctl restart apache2

echo "==================="

echo "Config Repositories: "

cd "$PROJECT_DIR"
[ -d OButecoBack-End ]  || git clone https://github.com/HenriqueHBM/OButecoBack-End.git
[ -d OButecoFront-End ] || git clone https://github.com/HenriqueHBM/OButecoFront-End.git


echo -e "DB_HOST=localhost
DB_PORT=5432
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD=$DB_PASSWORD
JWT_SECRET=$JWT_SECRET
CORS_ALLOWED_ORIGINS=$CORS_ALLOWED_ORIGINS
APP_ADMIN_SENHA=$APP_ADMIN_SENHA" > "$PROJECT_DIR/OButecoBack-End/.env"


echo "verify and build maven:"
cd "$PROJECT_DIR/OButecoBack-End"
mvn clean package -DskipTests


echo "Config Front-end:"
cd "$PROJECT_DIR/OButecoFront-End"

npm install
npx ng build

sudo cp -rf dist/obuteco-front-end/browser/. /var/www/html/

echo "============"
echo "Criando arquivo de config do apache: "

sudo tee /etc/apache2/sites-available/000-default.conf > /dev/null <<'EOF'
<VirtualHost *:80>
	ServerAdmin webmaster@localhost
	DocumentRoot /var/www/html
	ErrorLog ${APACHE_LOG_DIR}/error.log
	CustomLog ${APACHE_LOG_DIR}/access.log combined

	# [H] /api/* -> Spring Boot (porta 8080 só acessível internamente)
	ProxyPreserveHost On
	ProxyPass /api/ http://127.0.0.1:8080/
	ProxyPassReverse /api/ http://127.0.0.1:8080/
	RewriteEngine On

	# [H] não aplicar o fallback do Angular nas chamadas /api
	RewriteCond %{REQUEST_URI} ^/api/
	RewriteRule ^ - [L]
	RewriteCond %{DOCUMENT_ROOT}%{REQUEST_URI} -f [OR]
	RewriteCond %{DOCUMENT_ROOT}%{REQUEST_URI} -d
	RewriteRule ^ - [L]
	RewriteRule ^ /index.html
</VirtualHost>
EOF
sudo systemctl restart apache2

echo "Inicializando aplicacao back-end (systemd):"
sudo tee /etc/systemd/system/obuteco.service > /dev/null <<EOF
[Unit]
Description=OButeco Back-End (Spring Boot)
After=network.target postgresql.service
Requires=postgresql.service

[Service]
User=$(whoami)
WorkingDirectory=$PROJECT_DIR/OButecoBack-End
EnvironmentFile=$PROJECT_DIR/OButecoBack-End/.env
ExecStart=/usr/bin/java -jar $PROJECT_DIR/OButecoBack-End/target/OButecoBack-End-0.0.1-SNAPSHOT.jar
Restart=always
RestartSec=5
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now obuteco

sudo systemctl status obuteco --no-pager
sudo journalctl -u obuteco -n 50 --no-pager
